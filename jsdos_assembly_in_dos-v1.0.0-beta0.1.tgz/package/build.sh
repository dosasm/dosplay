yarn run build
yarn pack
cp jsdos_assembly_in_dos-v*.tgz dist